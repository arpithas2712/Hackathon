const express = require("express");
const cors = require("cors");
const multer = require("multer");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 5000;
const BASE = "/api/v1/docdesk";
const DATA_DIR = path.join(__dirname, "data");
const UPLOAD_DIR = path.join(__dirname, "uploads");
const DB_FILE = path.join(DATA_DIR, "db.json");

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify({users:[],docTypes:[],requests:[]}, null, 2));

app.use(cors());
app.use(express.json());
app.use(`${BASE}/files`, express.static(UPLOAD_DIR));

function readDB() { return JSON.parse(fs.readFileSync(DB_FILE, "utf8")); }
function writeDB(db) { fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2)); }
function id(prefix) { return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2,8)}`; }
function safeUser(req) {
  // Demo identity header. Replace with verified auth/JWT middleware for production.
  return { email: req.headers["x-user-email"] || "student@demo.com",
           role: req.headers["x-user-role"] || "student",
           name: req.headers["x-user-name"] || "Demo Student" };
}
function officeOnly(req,res,next) {
  if (safeUser(req).role !== "office") return res.status(403).json({error:"FORBIDDEN"});
  next();
}
function getRequest(db, rid) { return db.requests.find(r => r.request_id === rid); }
function publicFile(file) {
  if (!file) return null;
  return {file_id:file.file_id, filename:file.filename, content_type:file.content_type,
          size_bytes:file.size_bytes, url:`${BASE}/files/${encodeURIComponent(file.stored_name)}`};
}
const storage = multer.diskStorage({
  destination: (_,__,cb) => cb(null, UPLOAD_DIR),
  filename: (_,file,cb) => cb(null, `${Date.now()}-${Math.random().toString(16).slice(2)}${path.extname(file.originalname)}`)
});
const upload = multer({
  storage,
  limits:{fileSize:10*1024*1024},
  fileFilter: (_,file,cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const allowed = [".pdf",".docx",".jpg",".jpeg",".png"];
    if (!allowed.includes(ext)) return cb(new Error("Only PDF, DOCX, JPG and PNG files are allowed"));
    cb(null,true);
  }
});
function fileInfo(file) {
  return {file_id:id("FILE"), filename:file.originalname, content_type:file.mimetype,
          size_bytes:file.size, stored_name:file.filename};
}
function viewRequest(r) {
  return {...r, document:publicFile(r.document), filled_form:publicFile(r.filled_form)};
}
app.get("/", (_,res) => res.send("DocDesk Node.js API is running"));
app.post(`${BASE}/demo-login`, (req,res) => {
  const {email, role} = req.body || {};
  if (!email || !["student","office"].includes(role)) return res.status(400).json({error:"Email and valid role required"});
  const db=readDB();
  let user=db.users.find(u=>u.email.toLowerCase()===String(email).toLowerCase() && u.role===role);
  if (!user) user={email, name:role==="office"?"Student Affairs":"Demo Student", role, dept:"CSE"};
  res.json({user});
});

// Document types
app.get(`${BASE}/doc-types`, (req,res) => {
  const db=readDB(); const status=req.query.status || "active";
  res.json(db.docTypes.filter(t=>status==="all" ? true : t.status===status));
});
app.get(`${BASE}/doc-types/:id`, (req,res) => {
  const item=readDB().docTypes.find(t=>t.doc_type_id===req.params.id);
  item ? res.json(item) : res.status(404).json({error:"NOT_FOUND"});
});
app.post(`${BASE}/doc-types`, officeOnly, (req,res) => {
  const {name,description=""}=req.body || {};
  if (!name || name.trim().length<3 || name.trim().length>80) return res.status(400).json({error:"Name must be 3–80 characters"});
  const db=readDB();
  if (db.docTypes.some(t=>t.name.toLowerCase()===name.trim().toLowerCase())) return res.status(409).json({error:"ALREADY_EXISTS"});
  const item={doc_type_id:id("DTY"),name:name.trim(),description,status:"active"};
  db.docTypes.push(item); writeDB(db); res.status(201).json(item);
});
app.patch(`${BASE}/doc-types/:id`, officeOnly, (req,res) => {
  const db=readDB(), item=db.docTypes.find(t=>t.doc_type_id===req.params.id);
  if (!item) return res.status(404).json({error:"NOT_FOUND"});
  if (req.body.name) item.name=req.body.name.trim();
  if (req.body.description !== undefined) item.description=req.body.description;
  if (req.body.status && ["active","archived"].includes(req.body.status)) item.status=req.body.status;
  writeDB(db); res.json(item);
});
app.delete(`${BASE}/doc-types/:id`, officeOnly, (req,res) => {
  const db=readDB(), index=db.docTypes.findIndex(t=>t.doc_type_id===req.params.id);
  if(index<0) return res.status(404).json({error:"NOT_FOUND"});
  db.docTypes.splice(index,1); writeDB(db); res.json({success:true});
});

// Requests
app.post(`${BASE}/requests`, (req,res) => {
  const user=safeUser(req), {doc_type_id,reason}=req.body || {};
  if (!doc_type_id || !reason || reason.trim().length<5 || reason.trim().length>1000) return res.status(400).json({error:"Choose document type and enter reason (5–1000 chars)"});
  const db=readDB(), type=db.docTypes.find(t=>t.doc_type_id===doc_type_id);
  if(!type) return res.status(404).json({error:"DOCUMENT_TYPE_NOT_FOUND"});
  if(type.status!=="active") return res.status(409).json({error:"DOC_TYPE_ARCHIVED"});
  const item={request_id:id("DRQ"),doc_type_id,doc_type_name:type.name,reason:reason.trim(),status:"pending",
    requested_by:user.email,requested_by_name:user.name,requested_by_role:user.role,requested_by_dept:"CSE",
    created_at:new Date().toISOString(),updated_at:new Date().toISOString()};
  db.requests.unshift(item); writeDB(db); res.status(201).json(viewRequest(item));
});
app.get(`${BASE}/requests`, (req,res) => {
  const user=safeUser(req), db=readDB();
  let list=db.requests;
  if(user.role!=="office" && user.role!=="admin") list=list.filter(r=>r.requested_by===user.email);
  if(req.query.mine==="true" && user.role==="office") list=list.filter(r=>r.answered_by===user.email);
  if(req.query.status) list=list.filter(r=>r.status===req.query.status);
  if(req.query.doc_type_id) list=list.filter(r=>r.doc_type_id===req.query.doc_type_id);
  res.json(list.map(viewRequest));
});
app.get(`${BASE}/requests/:id`, (req,res) => {
  const user=safeUser(req), r=getRequest(readDB(),req.params.id);
  if(!r) return res.status(404).json({error:"NOT_FOUND"});
  if(user.role!=="office" && user.role!=="admin" && r.requested_by!==user.email) return res.status(403).json({error:"FORBIDDEN"});
  res.json(viewRequest(r));
});
app.patch(`${BASE}/requests/:id`, (req,res) => {
  const user=safeUser(req), db=readDB(), r=getRequest(db,req.params.id);
  if(!r) return res.status(404).json({error:"NOT_FOUND"});
  if(r.requested_by!==user.email) return res.status(403).json({error:"FORBIDDEN"});
  if(r.status!=="pending") return res.status(409).json({error:"REQUEST_NOT_PENDING"});
  if(req.body.reason!==undefined) {
    if(req.body.reason.trim().length<5 || req.body.reason.trim().length>1000) return res.status(400).json({error:"Reason must be 5–1000 characters"});
    r.reason=req.body.reason.trim();
  }
  if(req.body.doc_type_id) {
    const t=db.docTypes.find(x=>x.doc_type_id===req.body.doc_type_id && x.status==="active");
    if(!t) return res.status(409).json({error:"DOC_TYPE_ARCHIVED"});
    r.doc_type_id=t.doc_type_id; r.doc_type_name=t.name;
  }
  r.updated_at=new Date().toISOString(); writeDB(db); res.json(viewRequest(r));
});
app.delete(`${BASE}/requests/:id`, (req,res) => {
  const user=safeUser(req), db=readDB(), r=getRequest(db,req.params.id);
  if(!r) return res.status(404).json({error:"NOT_FOUND"});
  if(r.requested_by!==user.email) return res.status(403).json({error:"FORBIDDEN"});
  if(r.status!=="pending") return res.status(409).json({error:"REQUEST_NOT_PENDING"});
  db.requests=db.requests.filter(x=>x.request_id!==r.request_id); writeDB(db); res.json({success:true});
});
app.post(`${BASE}/requests/:id/answer`, officeOnly, upload.single("document"), (req,res) => {
  const db=readDB(), r=getRequest(db,req.params.id);
  if(!r) return res.status(404).json({error:"NOT_FOUND"});
  if(r.status!=="pending") return res.status(409).json({error:"REQUEST_NOT_PENDING"});
  const message=(req.body.message||"").trim();
  if(!message || message.length>2000) return res.status(400).json({error:"Message required (1–2000 chars)"});
  r.answer={message,answered_by:safeUser(req).email,answered_by_name:safeUser(req).name,answered_at:new Date().toISOString()};
  if(req.file) r.document=fileInfo(req.file);
  r.status="answered"; r.updated_at=new Date().toISOString(); writeDB(db); res.status(201).json(viewRequest(r));
});
app.patch(`${BASE}/requests/:id/answer`, officeOnly, upload.single("document"), (req,res) => {
  const db=readDB(), r=getRequest(db,req.params.id);
  if(!r) return res.status(404).json({error:"NOT_FOUND"});
  if(r.status==="acknowledged") return res.status(409).json({error:"ALREADY_ACKNOWLEDGED"});
  if(req.body.message) r.answer={...(r.answer||{}),message:req.body.message};
  if(req.file) r.document=fileInfo(req.file);
  if(req.body.remove_document==="true") r.document=null;
  writeDB(db); res.json(viewRequest(r));
});
app.delete(`${BASE}/requests/:id/answer`, officeOnly, (req,res) => {
  const db=readDB(), r=getRequest(db,req.params.id);
  if(!r) return res.status(404).json({error:"NOT_FOUND"});
  if(r.status!=="answered") return res.status(409).json({error:"NOT_ANSWERED"});
  r.answer=null; r.document=null; r.filled_form=null; r.status="pending"; writeDB(db); res.json(viewRequest(r));
});
app.post(`${BASE}/requests/:id/acknowledge`, (req,res) => {
  const user=safeUser(req), db=readDB(), r=getRequest(db,req.params.id);
  if(!r) return res.status(404).json({error:"NOT_FOUND"});
  if(r.requested_by!==user.email) return res.status(403).json({error:"FORBIDDEN"});
  if(r.status!=="answered") return res.status(409).json({error:"NOT_ANSWERED"});
  r.status="acknowledged"; r.acknowledged_at=new Date().toISOString(); writeDB(db); res.json(viewRequest(r));
});

// TAT
app.put(`${BASE}/requests/:id/tat`, officeOnly, (req,res) => {
  const db=readDB(), r=getRequest(db,req.params.id);
  if(!r) return res.status(404).json({error:"NOT_FOUND"});
  if(r.status!=="pending") return res.status(409).json({error:"REQUEST_NOT_PENDING"});
  if(!req.body.expected_by) return res.status(400).json({error:"expected_by required"});
  r.tat={expected_by:req.body.expected_by,note:req.body.note||"",updated_by:safeUser(req).email,updated_at:new Date().toISOString()};
  writeDB(db); res.json(viewRequest(r));
});
app.post(`${BASE}/requests/bulk-tat`, officeOnly, (req,res) => {
  const db=readDB(), {request_ids,expected_by,note=""}=req.body||{};
  if(!Array.isArray(request_ids)||request_ids.length<1||request_ids.length>100||!expected_by) return res.status(400).json({error:"Provide 1–100 request_ids and expected_by"});
  const selected=request_ids.map(x=>getRequest(db,x));
  if(selected.some(r=>!r || r.status!=="pending")) return res.status(409).json({error:"REQUEST_NOT_PENDING"});
  selected.forEach(r=>r.tat={expected_by,note,updated_by:safeUser(req).email,updated_at:new Date().toISOString()});
  writeDB(db); res.json({items:selected.map(viewRequest),count:selected.length});
});
app.put(`${BASE}/requests/:id/filled-form`, upload.single("file"), (req,res) => {
  const user=safeUser(req), db=readDB(), r=getRequest(db,req.params.id);
  if(!r) return res.status(404).json({error:"NOT_FOUND"});
  if(r.requested_by!==user.email) return res.status(403).json({error:"FORBIDDEN"});
  if(r.status!=="answered") return res.status(409).json({error:"NOT_ANSWERED"});
  if(!r.document) return res.status(409).json({error:"NO_DOCUMENT"});
  if(!req.file) return res.status(400).json({error:"file required"});
  r.filled_form=fileInfo(req.file); writeDB(db); res.json(viewRequest(r));
});
app.get(`${BASE}/requests/:id/document`, (req,res) => {
  const user=safeUser(req), r=getRequest(readDB(),req.params.id);
  if(!r) return res.status(404).json({error:"NOT_FOUND"});
  if(user.role!=="office" && user.role!=="admin" && r.requested_by!==user.email) return res.status(403).json({error:"FORBIDDEN"});
  if(!r.document) return res.status(404).json({error:"NO_DOCUMENT"});
  res.download(path.join(UPLOAD_DIR,r.document.stored_name),r.document.filename);
});
app.get(`${BASE}/requests/:id/filled-form`, (req,res) => {
  const user=safeUser(req), r=getRequest(readDB(),req.params.id);
  if(!r) return res.status(404).json({error:"NOT_FOUND"});
  if(user.role!=="office" && user.role!=="admin" && r.requested_by!==user.email) return res.status(403).json({error:"FORBIDDEN"});
  if(!r.filled_form) return res.status(404).json({error:"NO_FILLED_FORM"});
  res.download(path.join(UPLOAD_DIR,r.filled_form.stored_name),r.filled_form.filename);
});

app.use((err,req,res,next) => {
  console.error(err);
  res.status(err.code==="LIMIT_FILE_SIZE"?413:400).json({error:err.message||"UPLOAD_ERROR"});
});
app.listen(PORT,()=>console.log(`DocDesk API running at http://localhost:${PORT}`));
