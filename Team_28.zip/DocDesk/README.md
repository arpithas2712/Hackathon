# DocDesk – College Document Management System

## Requirements
- Node.js 20.19+ or 22.12+
- VS Code

## Run backend
Open a terminal:
```bash
cd backend
npm install
npm run dev
```
Backend: http://localhost:5000

## Run frontend
Open a SECOND terminal:
```bash
cd frontend
npm install
npm run dev
```
Frontend: http://localhost:5173

## Demo login
The login page has role buttons. Choose Student or Student Affairs and enter any non-empty email/password.
This is demo-only login. Replace with the organizer's authentication API before production.

## Notes
- Data is stored in `backend/data/db.json`.
- Uploaded files are stored in `backend/uploads`.
- This starter uses a local JSON file, not a production database.
- The API routes follow the uploaded DocDesk PDF base path `/api/v1/docdesk`.
- For a real hackathon submission, ask organizers for the official API base URL, authentication method, and whether you must use their server.
