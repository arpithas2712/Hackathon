import { useEffect, useMemo, useState } from "react";
import axios from "axios";
import { GraduationCap, LayoutDashboard, FileText, FolderOpen, User, LogOut, Bell, Plus, Clock, CheckCircle, Download, Settings, Search, Menu, X, ShieldCheck, Trash2, Pencil, Upload, RefreshCw } from "lucide-react";

const api = axios.create({ baseURL: "http://localhost:5000/api/v1/docdesk" });
const defaultUser = {email:"student@demo.com",name:"Demo Student",role:"student",dept:"CSE"};
function App() {
  const [user,setUser] = useState(()=>JSON.parse(localStorage.getItem("docdeskUser")||"null"));
  const [page,setPage] = useState("Dashboard");
  const [types,setTypes] = useState([]);
  const [requests,setRequests] = useState([]);
  const [loading,setLoading] = useState(false);
  const [notice,setNotice] = useState("");
  const [mobile,setMobile] = useState(false);
  const [selected,setSelected] = useState([]);
  const isOffice = user?.role==="office";
  const headers = user ? {"x-user-email":user.email,"x-user-role":user.role,"x-user-name":user.name} : {};
  const [loginRole,setLoginRole] = useState("student");
  const [email,setEmail] = useState("student@demo.com");
  const [password,setPassword] = useState("");

  const call = async (fn) => {
    try { setNotice(""); await fn(); }
    catch(e) { setNotice(e.response?.data?.error || e.message || "Something went wrong"); }
  };
  const load = async () => {
    if(!user) return;
    setLoading(true);
    try {
      const [t,r] = await Promise.all([
        api.get(isOffice ? "/doc-types?status=all" : "/doc-types",{headers}),
        api.get("/requests",{headers})
      ]);
      setTypes(t.data); setRequests(r.data);
    } catch(e) { setNotice(e.response?.data?.error || "Cannot connect to backend. Is Node.js server running?"); }
    finally { setLoading(false); }
  };
  useEffect(()=>{load();},[user?.email,user?.role]);
  const counts = useMemo(()=>({
    pending:requests.filter(r=>r.status==="pending").length,
    answered:requests.filter(r=>r.status==="answered").length,
    acknowledged:requests.filter(r=>r.status==="acknowledged").length
  }),[requests]);

  async function login(e) {
    e.preventDefault();
    await call(async()=>{
      const res=await api.post("/demo-login",{email,role:loginRole});
      localStorage.setItem("docdeskUser",JSON.stringify(res.data.user));
      setUser(res.data.user); setPage("Dashboard");
    });
  }
  function logout(){localStorage.removeItem("docdeskUser");setUser(null);setRequests([]);setTypes([]);}
  const nav = isOffice ? [
    ["Dashboard",LayoutDashboard],["All Requests",FileText],["Document Types",FolderOpen],["Turnaround Time",Clock]
  ] : [
    ["Dashboard",LayoutDashboard],["Request a Document",Plus],["My Requests",FileText],["Documents",FolderOpen],["Profile",User]
  ];

  if(!user) return <div className="login-wrap">
    <div className="login-art"><div className="logo-big"><GraduationCap size={56}/></div><h1>DocDesk</h1><p>College Document Management System</p><div className="art-card">Request <b>•</b> Track <b>•</b> Download</div><div className="campus">🏫</div></div>
    <form className="login-card" onSubmit={login}>
      <div className="brand-mini"><GraduationCap/> DocDesk <span>COLLEGE DOCUMENT PORTAL</span></div>
      <h2>Welcome to DocDesk!</h2><p className="muted">Login to continue</p>
      <div className="role-tabs">
        <button type="button" className={loginRole==="student"?"active":""} onClick={()=>{setLoginRole("student");setEmail("student@demo.com")}}>Student</button>
        <button type="button" className={loginRole==="office"?"active":""} onClick={()=>{setLoginRole("office");setEmail("office@demo.com")}}>Student Affairs</button>
      </div>
      <label>Email / Username</label><input required type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="Enter email"/>
      <label>Password</label><input required type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Enter password"/>
      <p className="hint">Demo: choose a role and enter any password.</p>
      <button className="primary full" type="submit">Login</button>
      <p className="muted tiny">Demo sign-in only • Connect college authentication before production</p>
      {notice && <div className="alert">{notice}</div>}
    </form>
  </div>;

  return <div className="app-shell">
    <header className="topbar">
      <button className="icon-btn mobile-only" onClick={()=>setMobile(!mobile)}><Menu/></button>
      <div className="brand"><GraduationCap size={27}/> <b>DocDesk</b><span>COLLEGE DOCUMENT PORTAL</span></div>
      <div className="top-right"><Bell size={18}/><span className="avatar">{isOffice?"SA":"S"}</span><span>{isOffice?"Student Affairs":"Student"}</span><button className="icon-btn" onClick={logout} title="Logout"><LogOut size={18}/></button></div>
    </header>
    <div className="layout">
      <aside className={`sidebar ${mobile?"show":""}`}>
        <div className="side-user"><div className="avatar large">{isOffice?"SA":"S"}</div><div><b>{user.name}</b><small>{isOffice?"Student Affairs":"Student • "+(user.dept||"CSE")}</small></div><button className="icon-btn mobile-only" onClick={()=>setMobile(false)}><X/></button></div>
        {nav.map(([name,Icon])=><button key={name} className={`nav-item ${page===name?"selected":""}`} onClick={()=>{setPage(name);setMobile(false)}}><Icon size={18}/>{name}</button>)}
        <button className="nav-item logout" onClick={logout}><LogOut size={18}/>Logout</button>
        <div className="side-foot">DocDesk v1.0<br/>College Document Portal</div>
      </aside>
      <main className="main">
        <div className="page-head"><div><div className="eyebrow">{isOffice?"STUDENT AFFAIRS PANEL":"STUDENT PORTAL"}</div><h1>{page==="Dashboard"?(isOffice?"Admin Dashboard":"Welcome to DocDesk!") : page}</h1><p>{page==="Dashboard"?"Request, track and download your college documents easily.":"Manage your college document requests in one place."}</p></div><button className="outline" onClick={load}><RefreshCw size={16}/> Refresh</button></div>
        {notice && <div className="alert">{notice}<button onClick={()=>setNotice("")}>×</button></div>}
        {loading && <div className="loading">Loading data…</div>}
        {page==="Dashboard" && <Dashboard isOffice={isOffice} counts={counts} requests={requests} setPage={setPage}/>}
        {page==="Request a Document" && !isOffice && <RequestForm types={types} headers={headers} call={call} reload={load}/>}
        {page==="My Requests" && <Requests requests={requests} isOffice={isOffice} headers={headers} call={call} reload={load}/>}
        {page==="All Requests" && isOffice && <Requests requests={requests} isOffice headers={headers} call={call} reload={load}/>}
        {page==="Documents" && !isOffice && <Documents requests={requests} headers={headers} call={call} reload={load}/>}
        {page==="Document Types" && isOffice && <ManageTypes types={types} headers={headers} call={call} reload={load}/>}
        {page==="Turnaround Time" && isOffice && <Tat requests={requests} headers={headers} call={call} reload={load}/>}
        {page==="Profile" && <div className="panel"><h3>Profile</h3><p><b>Name:</b> {user.name}</p><p><b>Email:</b> {user.email}</p><p><b>Role:</b> {user.role}</p><p><b>Department:</b> {user.dept||"CSE"}</p></div>}
      </main>
    </div>
  </div>;
}

function Dashboard({isOffice,counts,requests,setPage}) {
  const cards=isOffice?[
    ["Pending",counts.pending,"#f5a623",Clock],["Answered",counts.answered,"#20a56b",CheckCircle],["Doc Types","", "#7654d6",FolderOpen],["Acknowledged",counts.acknowledged,"#2563c9",ShieldCheck]
  ]:[
    ["Pending",counts.pending,"#f5a623",Clock],["Answered",counts.answered,"#2563c9",CheckCircle],["Acknowledged",counts.acknowledged,"#20a56b",ShieldCheck],["Total Requests",requests.length,"#7654d6",FileText]
  ];
  return <>
    <div className="welcome-banner"><div><span className="eyebrow">YOUR DOCUMENTS, ONE PLACE</span><h2>{isOffice?"Manage student document requests":"Hello, "+(isOffice?"Team": "Student")+"!"}</h2><p>{isOffice?"Review requests, provide answers and manage turnaround times.":"Request, track and download your college documents easily."}</p></div><GraduationCap size={68}/></div>
    <div className="stats-grid">{cards.map(([label,value,color,Icon])=><div className="stat-card" key={label}><div className="stat-icon" style={{color}}><Icon/></div><div><small>{label}</small><strong>{label==="Doc Types"?"—":value}</strong></div></div>)}</div>
    <div className="quick-grid">
      {!isOffice && <><Quick title="Request a Document" text="Get your document from Student Affairs" action="New Request" onClick={()=>setPage("Request a Document")} icon={Plus}/><Quick title="My Requests" text="Track your requests" action="View Status" onClick={()=>setPage("My Requests")} icon={Clock}/><Quick title="My Documents" text="Download your files" action="View Files" onClick={()=>setPage("Documents")} icon={Download}/><Quick title="Profile" text="View your profile details" action="View Profile" onClick={()=>setPage("Profile")} icon={Settings}/></>}
      {isOffice && <><Quick title="All Requests" text="Review incoming student requests" action="View Requests" onClick={()=>setPage("All Requests")} icon={FileText}/><Quick title="Manage Document Types" text="Add or archive document types" action="Manage Types" onClick={()=>setPage("Document Types")} icon={FolderOpen}/><Quick title="Turnaround Time" text="Set expected completion dates" action="Set TAT" onClick={()=>setPage("Turnaround Time")} icon={Clock}/></>}
    </div>
    <div className="panel"><div className="panel-head"><h3>{isOffice?"Recent Requests":"Recent My Requests"}</h3><button className="text-btn" onClick={()=>setPage(isOffice?"All Requests":"My Requests")}>View all →</button></div><RequestTable requests={requests.slice(0,5)} isOffice={isOffice}/></div>
  </>;
}
function Quick({title,text,action,onClick,icon:Icon}){return <div className="quick-card"><div className="quick-icon"><Icon/></div><div><b>{title}</b><p>{text}</p><button className="small-primary" onClick={onClick}>{action}</button></div></div>}

function RequestForm({types,headers,call,reload}) {
  const [type,setType]=useState(""); const [reason,setReason]=useState("");
  async function submit(e){e.preventDefault();await call(async()=>{await api.post("/requests",{doc_type_id:type,reason},{headers});setType("");setReason("");alert("Request submitted successfully!");await reload();});}
  return <div className="two-col"><form className="panel form-panel" onSubmit={submit}><h3>Request a Document</h3><p className="muted">Select the document you need and tell us why.</p><label>Document Type <em>*</em></label><select required value={type} onChange={e=>setType(e.target.value)}><option value="">Select Document Type</option>{types.map(t=><option key={t.doc_type_id} value={t.doc_type_id}>{t.name}</option>)}</select><label>Reason for Request <em>*</em></label><textarea required minLength="5" maxLength="1000" value={reason} onChange={e=>setReason(e.target.value)} placeholder="Enter your reason (5–1000 characters)…"/><div className="form-actions"><button className="primary">Submit Request</button><button type="reset" className="outline" onClick={()=>{setType("");setReason("")}}>Reset</button></div></form><div className="panel"><h3>Available Documents</h3><p className="muted">Choose from active document types.</p>{types.map(t=><div className="available" key={t.doc_type_id}><CheckCircle size={17}/><div><b>{t.name}</b><small>{t.description}</small></div></div>)}</div></div>;
}

function RequestTable({requests,isOffice}) {
  if(!requests.length) return <div className="empty">No requests yet. Create your first document request.</div>;
  return <div className="table-wrap"><table><thead><tr><th>Document</th><th>Applied Date</th><th>Requested By</th><th>Status</th><th>Expected By</th></tr></thead><tbody>{requests.map(r=><tr key={r.request_id}><td><b>{r.doc_type_name}</b><small className="subline">{r.request_id}</small></td><td>{new Date(r.created_at).toLocaleDateString()}</td><td>{isOffice?r.requested_by_name:r.requested_by}</td><td><Status status={r.status}/></td><td>{r.tat?.expected_by||"—"}</td></tr>)}</tbody></table></div>;
}
function Status({status}){return <span className={`status ${status}`}>{status}</span>}

function Requests({requests,isOffice,headers,call,reload}) {
  const [filter,setFilter]=useState("all"); const [answerId,setAnswerId]=useState(null); const [message,setMessage]=useState(""); const [doc,setDoc]=useState(null); const [edit,setEdit]=useState(null);
  const list=filter==="all"?requests:requests.filter(r=>r.status===filter);
  async function answer(e){e.preventDefault();await call(async()=>{const fd=new FormData();fd.append("message",message);if(doc)fd.append("document",doc);await api.post(`/requests/${answerId}/answer`,fd,{headers});setAnswerId(null);setMessage("");setDoc(null);await reload();});}
  async function acknowledge(id){await call(async()=>{await api.post(`/requests/${id}/acknowledge`,{}, {headers});await reload();});}
  async function withdraw(id){if(!confirm("Withdraw this pending request?"))return;await call(async()=>{await api.delete(`/requests/${id}`,{headers});await reload();});}
  async function saveEdit(e){e.preventDefault();await call(async()=>{await api.patch(`/requests/${edit.request_id}`,{reason:edit.reason},{headers});setEdit(null);await reload();});}
  return <div className="panel"><div className="filter-row"><div className="filters">{["all","pending","answered","acknowledged"].map(x=><button key={x} className={filter===x?"filter active":"filter"} onClick={()=>setFilter(x)}>{x==="all"?"All":x[0].toUpperCase()+x.slice(1)}</button>)}</div><span className="muted">{list.length} request(s)</span></div>
    <RequestTable requests={list} isOffice={isOffice}/>
    {list.map(r=><div className="request-actions" key={r.request_id}><div><b>{r.doc_type_name}</b><small>{r.request_id} · {r.reason}</small>{r.answer?.message&&<p className="answer-text">Answer: {r.answer.message}</p>}</div><div className="action-buttons">
      {!isOffice && r.status==="pending" && <><button className="outline tiny-btn" onClick={()=>setEdit(r)}>Edit</button><button className="danger tiny-btn" onClick={()=>withdraw(r.request_id)}>Withdraw</button></>}
      {isOffice && r.status==="pending" && <button className="primary tiny-btn" onClick={()=>{setAnswerId(r.request_id);setMessage("");}}>Answer</button>}
      {!isOffice && r.status==="answered" && <><a className="outline tiny-btn" href={`http://localhost:5000/api/v1/docdesk/requests/${r.request_id}/document`} onClick={e=>{e.preventDefault();call(async()=>{const res=await api.get(`/requests/${r.request_id}/document`,{headers,responseType:"blob"});const url=URL.createObjectURL(res.data);const a=document.createElement("a");a.href=url;a.download=r.document?.filename||"document";a.click();URL.revokeObjectURL(url);});}}>Download</a><label className="upload-btn">Upload filled form<input type="file" hidden accept=".pdf,.docx,.jpg,.jpeg,.png" onChange={e=>{const f=e.target.files[0];if(f)call(async()=>{const fd=new FormData();fd.append("file",f);await api.put(`/requests/${r.request_id}/filled-form`,fd,{headers});await reload();});}}/></label><button className="primary tiny-btn" onClick={()=>acknowledge(r.request_id)}>Acknowledge</button></>}
      {isOffice && r.filled_form && <a className="outline tiny-btn" href={`http://localhost:5000${r.filled_form.url}`} target="_blank">Filled form</a>}
    </div></div>)}
    {answerId && <div className="modal-backdrop"><form className="modal panel" onSubmit={answer}><button type="button" className="modal-x" onClick={()=>setAnswerId(null)}>×</button><h3>Answer Request</h3><label>Answer message</label><textarea required maxLength="2000" value={message} onChange={e=>setMessage(e.target.value)} placeholder="Enter your answer…"/><label>Upload document (PDF or DOCX, max 10 MB)</label><input type="file" accept=".pdf,.docx" onChange={e=>setDoc(e.target.files[0])}/><button className="primary">Submit Answer</button></form></div>}
    {edit && <div className="modal-backdrop"><form className="modal panel" onSubmit={saveEdit}><button type="button" className="modal-x" onClick={()=>setEdit(null)}>×</button><h3>Edit Pending Request</h3><label>Reason</label><textarea minLength="5" required value={edit.reason} onChange={e=>setEdit({...edit,reason:e.target.value})}/><button className="primary">Save Changes</button></form></div>}
  </div>;
}

function Documents({requests,headers,call}) {
  const ready=requests.filter(r=>r.document);
  async function download(r){await call(async()=>{const res=await api.get(`/requests/${r.request_id}/document`,{headers,responseType:"blob"});const url=URL.createObjectURL(res.data);const a=document.createElement("a");a.href=url;a.download=r.document.filename;a.click();URL.revokeObjectURL(url);});}
  return <div className="panel"><h3>My Documents</h3>{ready.length?ready.map(r=><div className="doc-row" key={r.request_id}><FileText/><div><b>{r.document.filename}</b><small>{r.doc_type_name} · {r.status}</small></div><button className="outline" onClick={()=>download(r)}><Download size={16}/> Download</button></div>):<div className="empty">No documents available yet. Documents shared by Student Affairs will appear here.</div>}</div>;
}
function ManageTypes({types,headers,call,reload}) {
  const [name,setName]=useState("");const [description,setDescription]=useState("");const [editing,setEditing]=useState(null);
  async function add(e){e.preventDefault();await call(async()=>{await api.post("/doc-types",{name,description},{headers});setName("");setDescription("");await reload();});}
  async function update(t,status){await call(async()=>{await api.patch(`/doc-types/${t.doc_type_id}`,{status},{headers});await reload();});}
  async function remove(t){if(!confirm("Permanently delete this document type?"))return;await call(async()=>{await api.delete(`/doc-types/${t.doc_type_id}`,{headers});await reload();});}
  async function save(e){e.preventDefault();await call(async()=>{await api.patch(`/doc-types/${editing.doc_type_id}`,{name:editing.name,description:editing.description},{headers});setEditing(null);await reload();});}
  return <div className="two-col"><form className="panel form-panel" onSubmit={add}><h3>Add Document Type</h3><label>Document name</label><input required minLength="3" maxLength="80" value={name} onChange={e=>setName(e.target.value)} placeholder="e.g. Bonafide Certificate"/><label>Description</label><textarea value={description} onChange={e=>setDescription(e.target.value)} placeholder="Short description"/><button className="primary"><Plus size={16}/> Add Document Type</button></form><div className="panel"><h3>Manage Document Types</h3>{types.map(t=><div className="type-row" key={t.doc_type_id}><div><b>{t.name}</b><small>{t.description} · {t.status}</small></div><div className="action-buttons"><button className="outline tiny-btn" onClick={()=>setEditing(t)}><Pencil size={14}/> Edit</button><button className="outline tiny-btn" onClick={()=>update(t,t.status==="active"?"archived":"active")}>{t.status==="active"?"Archive":"Activate"}</button><button className="danger tiny-btn" onClick={()=>remove(t)}><Trash2 size={14}/></button></div></div>)}</div>
    {editing&&<div className="modal-backdrop"><form className="modal panel" onSubmit={save}><button type="button" className="modal-x" onClick={()=>setEditing(null)}>×</button><h3>Edit Document Type</h3><label>Name</label><input value={editing.name} onChange={e=>setEditing({...editing,name:e.target.value})}/><label>Description</label><textarea value={editing.description||""} onChange={e=>setEditing({...editing,description:e.target.value})}/><button className="primary">Save</button></form></div>}
  </div>;
}
function Tat({requests,headers,call,reload}) {
  const pending=requests.filter(r=>r.status==="pending");const [date,setDate]=useState("");const [note,setNote]=useState("");const [ids,setIds]=useState([]);
  async function one(id){if(!date)return alert("Select expected date");await call(async()=>{await api.put(`/requests/${id}/tat`,{expected_by:date,note},{headers});await reload();});}
  async function bulk(){if(!date||!ids.length)return alert("Select requests and expected date");await call(async()=>{await api.post("/requests/bulk-tat",{request_ids:ids,expected_by:date,note},{headers});setIds([]);await reload();});}
  return <div className="panel"><h3>Set Turnaround Time (TAT)</h3><p className="muted">Only pending requests can receive or update a turnaround date.</p><div className="tat-controls"><div><label>Expected by</label><input type="date" value={date} min={new Date().toISOString().slice(0,10)} onChange={e=>setDate(e.target.value)}/></div><div><label>Note</label><input value={note} onChange={e=>setNote(e.target.value)} placeholder="Optional note"/></div><button className="primary" onClick={bulk}>Update Selected ({ids.length})</button></div><div className="table-wrap"><table><thead><tr><th>Select</th><th>Document</th><th>Student</th><th>Expected By</th><th>Action</th></tr></thead><tbody>{pending.map(r=><tr key={r.request_id}><td><input type="checkbox" checked={ids.includes(r.request_id)} onChange={e=>setIds(e.target.checked?[...ids,r.request_id]:ids.filter(x=>x!==r.request_id))}/></td><td>{r.doc_type_name}</td><td>{r.requested_by_name}</td><td>{r.tat?.expected_by||"Not set"}</td><td><button className="small-primary" onClick={()=>one(r.request_id)}>Set TAT</button></td></tr>)}</tbody></table></div>{!pending.length&&<div className="empty">No pending requests.</div>}</div>;
}
export default App;
